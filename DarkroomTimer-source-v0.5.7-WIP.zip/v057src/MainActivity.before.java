package it.darkroom.timer;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputFilter;
import android.view.Gravity;
import android.view.Window;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public final class MainActivity extends Activity implements SonoffDiscovery.Listener {
    private int GREEN;
    private int BLUE;
    private int CARD;
    private int BUTTON;
    private int BORDER;
    private int MUTED;
    private int AMBER;
    private int RED;
    private int PURPLE;
    private int TEXT_PRIMARY;
    private boolean darkroomMode;
    private boolean feedbackBeep;

    private static final int MODE_PRINT = 0;
    private static final int MODE_TEST = 1;
    private static final int MODE_LOG = 2;

    private static final int REQ_EXPORT_BACKUP = 4101;
    private static final int REQ_IMPORT_BACKUP = 4102;
    private static final int REQ_EXPORT_JPG = 4103;
    private static final String APP_VERSION = "0.5.6";

    private static final class FoundDevice {
        final DeviceConfig config;
        final boolean diyCandidate;
        final String type;
        final String apiVersion;

        FoundDevice(DeviceConfig config, boolean diyCandidate, String type, String apiVersion) {
            this.config = config;
            this.diyCandidate = diyCandidate;
            this.type = type == null ? "" : type;
            this.apiVersion = apiVersion == null ? "" : apiVersion;
        }

        String modeLabel() { return diyCandidate ? "possibile DIY" : "eWeLink"; }
    }

    private TextView deviceStatus;
    private TextView stateText;
    private TextView printTimeText;
    private TextView testTimeText;
    private TextView testCountText;
    private TextView testPauseText;
    private TextView testCumulativeText;
    private Button actionButton;
    private Button normalButton;
    private Button selectDeviceButton;
    private Button printModeButton;
    private Button testModeButton;
    private Button logModeButton;
    private Button saveLogButton;
    private LinearLayout printPanel;
    private LinearLayout testPanel;
    private LinearLayout logPanel;
    private LinearLayout logListContainer;

    private SonoffDiscovery discovery;
    private DeviceConfig device;
    private String selectedDeviceId;
    private int mode = MODE_PRINT;
    private int printWidthMs = 8500;
    private int testWidthMs = 2000;
    private int testCount = 7;
    private int testPauseMs = 2000;
    private boolean armed = false;
    private LogEntry pendingJpegEntry;

    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Map<String, FoundDevice> foundDevices = new LinkedHashMap<>();
    private final Handler reconnectHandler = new Handler(Looper.getMainLooper());
    private final AtomicBoolean validationInFlight = new AtomicBoolean(false);
    private final AtomicBoolean healthCheckInFlight = new AtomicBoolean(false);
    private int connectionFailures = 0;
    private boolean activityStarted = false;
    private final Runnable reconnectRunnable = new Runnable() {
        @Override public void run() {
            if (!activityStarted) return;
            DeviceConfig saved = DeviceConfig.load(MainActivity.this);
            if (saved.isValid() && saved.deviceId.equals(selectedDeviceId)) {
                if (armed) {
                    // During a cycle SonoffArmService already polls the MINIR2.
                    // Do not add UI heartbeat traffic to the timing path.
                } else if (device != null && device.isValid()) {
                    healthCheckSelected(saved);
                } else {
                    validateSelected(saved);
                }
            }
            if (activityStarted) reconnectHandler.postDelayed(this, 3000L);
        }
    };

    private final BroadcastReceiver stateReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            applyRuntimeState(
                    intent.getStringExtra(SonoffArmService.EXTRA_STATE),
                    intent.getStringExtra(SonoffArmService.EXTRA_MESSAGE));
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SharedPreferences p = getSharedPreferences("ui", MODE_PRIVATE);
        darkroomMode = p.getBoolean("darkroomMode", false);
        feedbackBeep = p.getBoolean("feedbackBeep", true);
        configurePalette();
        applyDarkroomWindow();
        mode = p.getInt("mode", MODE_PRINT);
        printWidthMs = p.getInt("printWidthMs", 8500);
        testWidthMs = p.getInt("testWidthMs", 2000);
        testCount = p.getInt("testCount", 7);
        testPauseMs = p.getInt("testPauseMs", 2000);

        DeviceConfig saved = DeviceConfig.load(this);
        selectedDeviceId = saved.deviceId == null ? "" : saved.deviceId.trim();
        device = null;
        buildUi();
        applyModeUi();
        updateSelectionUiBeforeDiscovery();
    }

    @Override protected void onStart() {
        super.onStart();
        activityStarted = true;
        IntentFilter f = new IntentFilter(SonoffArmService.BROADCAST_STATE);
        if (Build.VERSION.SDK_INT >= 33) {
            try {
                java.lang.reflect.Method m = Context.class.getMethod("registerReceiver", BroadcastReceiver.class, IntentFilter.class, int.class);
                m.invoke(this, stateReceiver, f, 4); // RECEIVER_NOT_EXPORTED
            } catch (Exception e) {
                registerReceiver(stateReceiver, f);
            }
        } else {
            registerReceiver(stateReceiver, f);
        }
        restoreRuntimeState();
        foundDevices.clear();
        discovery = new SonoffDiscovery(this, this);
        discovery.start();

        // Do not depend only on mDNS. The selected MINIR2 was already verified in
        // previous runs, so probe the last known address immediately while NSD
        // independently searches by immutable Device ID (and can update the IP).
        DeviceConfig saved = DeviceConfig.load(this);
        if (saved.isValid() && saved.deviceId.equals(selectedDeviceId)) {
            validateSelected(saved);
        }
        reconnectHandler.removeCallbacks(reconnectRunnable);
        reconnectHandler.postDelayed(reconnectRunnable, 3000L);
    }

    @Override protected void onResume() {
        super.onResume();
        // A cycle may have completed while the screen/activity was stopped.
        // Re-read the service's durable state instead of relying on a missed broadcast.
        restoreRuntimeState();
    }

    @Override protected void onStop() {
        activityStarted = false;
        reconnectHandler.removeCallbacks(reconnectRunnable);
        if (discovery != null) discovery.stop();
        discovery = null;
        try { unregisterReceiver(stateReceiver); } catch (Exception ignored) {}
        super.onStop();
    }

    @Override protected void onDestroy() {
        io.shutdownNow();
        super.onDestroy();
    }

    private void restoreRuntimeState() {
        applyRuntimeState(
                SonoffArmService.loadLastState(this),
                SonoffArmService.loadLastMessage(this));
    }

    private void applyRuntimeState(String state, String message) {
        if (state == null || state.trim().isEmpty()) state = SonoffArmService.STATE_NORMAL;

        boolean busy = SonoffArmService.STATE_ARMED.equals(state)
                || SonoffArmService.STATE_ARMING.equals(state)
                || SonoffArmService.STATE_EXPOSING.equals(state)
                || SonoffArmService.STATE_PAUSING.equals(state)
                || SonoffArmService.STATE_DISARMING.equals(state);

        if (busy) {
            armed = true;
            setControlsEnabled(false);
            normalButton.setVisibility(View.GONE);
        } else if (SonoffArmService.STATE_ERROR.equals(state)) {
            armed = false;
            setControlsEnabled(device != null && device.isValid());
            normalButton.setVisibility(View.VISIBLE);
            normalButton.setEnabled(device != null && device.isValid());
            normalButton.setAlpha(normalButton.isEnabled() ? 1f : (darkroomMode ? 0.62f : 0.45f));
            if (message != null && !message.trim().isEmpty()) stateText.setText(message);
            stateText.setTextColor(RED);
            return;
        } else {
            // NORMAL (or any unknown stale value): the cycle is no longer locking the UI.
            armed = false;
            normalButton.setVisibility(View.GONE);
            setControlsEnabled(device != null && device.isValid());
        }

        if (message != null && !message.trim().isEmpty()) {
            stateText.setText(message);
        } else if (!busy && device != null && device.isValid()) {
            stateText.setText("PRONTO — scegli il tempo e premi ARMA");
        }

        if (!busy && mode != MODE_LOG && shouldOfferQuickSave()) {
            saveLogButton.setVisibility(View.VISIBLE);
        } else if (mode == MODE_LOG || busy) {
            saveLogButton.setVisibility(View.GONE);
        }

        if (SonoffArmService.STATE_EXPOSING.equals(state)) {
            stateText.setTextColor(mode == MODE_TEST ? BLUE : GREEN);
        } else if (SonoffArmService.STATE_PAUSING.equals(state)) {
            stateText.setTextColor(BLUE);
        } else {
            stateText.setTextColor(MUTED);
        }
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.BLACK);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(14), dp(16), dp(28));
        scroll.addView(root, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = text("Darkroom Timer", 25, TEXT_PRIMARY, true);
        title.setGravity(Gravity.CENTER);
        root.addView(title, lp(-1, dp(48)));

        LinearLayout deviceCard = card();
        LinearLayout deviceTop = new LinearLayout(this);
        deviceTop.setOrientation(LinearLayout.HORIZONTAL);
        deviceTop.setGravity(Gravity.CENTER_VERTICAL);
        TextView deviceName = text("INGRANDITORE", 14, TEXT_PRIMARY, true);
        deviceTop.addView(deviceName, lp(0, -2, 1f));
        selectDeviceButton = compactButton("⚙");
        selectDeviceButton.setTextSize(20);
        selectDeviceButton.setOnClickListener(v -> showSettingsDialog());
        deviceTop.addView(selectDeviceButton, lp(dp(56), dp(40)));
        deviceCard.addView(deviceTop);
        deviceStatus = text("Cerco i SONOFF sulla rete…", 13, MUTED, false);
        deviceStatus.setPadding(0, dp(8), 0, 0);
        deviceCard.addView(deviceStatus);
        root.addView(deviceCard, margin(lp(-1, -2), 0, 4, 0, 14));

        LinearLayout modeRow = new LinearLayout(this);
        modeRow.setOrientation(LinearLayout.HORIZONTAL);
        printModeButton = modeButton("STAMPA");
        testModeButton = modeButton("PROVINO");
        logModeButton = modeButton("LOG");
        printModeButton.setOnClickListener(v -> setMode(MODE_PRINT));
        testModeButton.setOnClickListener(v -> setMode(MODE_TEST));
        logModeButton.setOnClickListener(v -> setMode(MODE_LOG));
        modeRow.addView(printModeButton, margin(lp(0, dp(52), 1f), 0, 0, dp(4), 0));
        modeRow.addView(testModeButton, margin(lp(0, dp(52), 1f), dp(4), 0, dp(4), 0));
        modeRow.addView(logModeButton, margin(lp(0, dp(52), 0.72f), dp(4), 0, 0, 0));
        root.addView(modeRow, margin(lp(-1, -2), 0, 0, 0, 12));

        printPanel = buildPrintPanel();
        testPanel = buildTestPanel();
        logPanel = buildLogPanel();
        root.addView(printPanel, lp(-1, -2));
        root.addView(testPanel, lp(-1, -2));
        root.addView(logPanel, lp(-1, -2));

        actionButton = new Button(this);
        actionButton.setTextColor(TEXT_PRIMARY);
        actionButton.setTextSize(18);
        actionButton.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        actionButton.setAllCaps(false);
        actionButton.setOnClickListener(v -> arm());
        root.addView(actionButton, margin(lp(-1, dp(64)), 0, 14, 0, 0));

        saveLogButton = new Button(this);
        saveLogButton.setText("SALVA NEL LOG");
        saveLogButton.setTextSize(16);
        saveLogButton.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        saveLogButton.setAllCaps(false);
        saveLogButton.setTextColor(darkroomMode ? Color.BLACK : TEXT_PRIMARY);
        saveLogButton.setBackground(roundRect(darkroomMode ? RED : PURPLE, 10, 0, 0));
        saveLogButton.setOnClickListener(v -> showLogEditor(newEntryFromSession(), true));
        saveLogButton.setVisibility(View.GONE);
        root.addView(saveLogButton, margin(lp(-1, dp(56)), 0, 8, 0, 0));

        stateText = text("PRONTO", 16, MUTED, true);
        stateText.setGravity(Gravity.CENTER);
        stateText.setPadding(dp(6), dp(13), dp(6), dp(13));
        root.addView(stateText, lp(-1, -2));

        normalButton = new Button(this);
        normalButton.setText("⚠  RIPRISTINO EMERGENZA\nSpegne l’uscita e disattiva Inching");
        normalButton.setTextColor(TEXT_PRIMARY);
        normalButton.setTextSize(14);
        normalButton.setAllCaps(false);
        normalButton.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        normalButton.setPadding(dp(20), 0, dp(12), 0);
        normalButton.setBackground(roundRect(CARD, 10, 1, BORDER));
        normalButton.setOnClickListener(v -> disarm());
        normalButton.setVisibility(View.GONE);
        root.addView(normalButton, lp(-1, dp(64)));

        TextView footer = text("Darkroom Timer di F.G. - v" + APP_VERSION, 12, darkroomMode ? Color.rgb(92, 18, 18) : Color.rgb(105, 112, 118), false);
        footer.setGravity(Gravity.CENTER);
        root.addView(footer, margin(lp(-1, dp(46)), 0, 10, 0, 0));

        setContentView(scroll);
        setControlsEnabled(false);
    }

    private LinearLayout buildPrintPanel() {
        LinearLayout box = card();
        TextView prompt = text("Tempo di stampa", 16, TEXT_PRIMARY, true);
        prompt.setGravity(Gravity.CENTER);
        box.addView(prompt);
        TextView sub = text("Singola esposizione • passo 0,5 s", 13, MUTED, false);
        sub.setGravity(Gravity.CENTER);
        box.addView(sub);
        box.addView(space(12));

        LinearLayout selector = new LinearLayout(this);
        selector.setGravity(Gravity.CENTER);
        selector.setOrientation(LinearLayout.HORIZONTAL);
        Button minus = smallButton("−");
        Button plus = smallButton("+");
        printTimeText = text(formatTime(printWidthMs), 48, GREEN, true);
        printTimeText.setGravity(Gravity.CENTER);
        selector.addView(minus, lp(dp(62), dp(58)));
        selector.addView(printTimeText, lp(0, dp(68), 1f));
        selector.addView(plus, lp(dp(62), dp(58)));
        minus.setOnClickListener(v -> setPrintTime(printWidthMs - 500));
        plus.setOnClickListener(v -> setPrintTime(printWidthMs + 500));
        box.addView(selector);
        box.addView(space(12));

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(4);
        int[] secs = {2, 3, 4, 5, 6, 8, 10, 15};
        for (int s : secs) {
            Button b = shortcutButton(s + " s", GREEN);
            GridLayout.LayoutParams gp = new GridLayout.LayoutParams();
            gp.width = dp(74);
            gp.height = dp(46);
            gp.setMargins(dp(4), dp(4), dp(4), dp(4));
            grid.addView(b, gp);
            b.setOnClickListener(v -> setPrintTime(s * 1000));
        }
        box.addView(grid, lp(-1, -2));
        return box;
    }

    private LinearLayout buildTestPanel() {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);

        LinearLayout exposure = card();
        TextView prompt = text("Incremento del provino", 16, TEXT_PRIMARY, true);
        prompt.setGravity(Gravity.CENTER);
        exposure.addView(prompt);
        TextView sub = text("Ogni esposizione ha lo stesso tempo", 13, MUTED, false);
        sub.setGravity(Gravity.CENTER);
        exposure.addView(sub);
        exposure.addView(space(10));

        LinearLayout selector = new LinearLayout(this);
        selector.setGravity(Gravity.CENTER);
        selector.setOrientation(LinearLayout.HORIZONTAL);
        Button minus = smallButton("−");
        Button plus = smallButton("+");
        testTimeText = text(formatTime(testWidthMs), 44, BLUE, true);
        testTimeText.setGravity(Gravity.CENTER);
        selector.addView(minus, lp(dp(62), dp(58)));
        selector.addView(testTimeText, lp(0, dp(64), 1f));
        selector.addView(plus, lp(dp(62), dp(58)));
        minus.setOnClickListener(v -> setTestTime(testWidthMs - 500));
        plus.setOnClickListener(v -> setTestTime(testWidthMs + 500));
        exposure.addView(selector);
        testCumulativeText = text(cumulativeTimes(), 13, BLUE, true);
        testCumulativeText.setGravity(Gravity.CENTER);
        testCumulativeText.setPadding(dp(6), dp(6), dp(6), 0);
        exposure.addView(testCumulativeText, lp(-1, -2));
        outer.addView(exposure, margin(lp(-1, -2), 0, 0, 0, 10));

        LinearLayout settings = card();
        settings.addView(stepperRow("NUMERO ESPOSIZIONI", true));
        settings.addView(divider());
        settings.addView(stepperRow("PAUSA TRA LE ESPOSIZIONI", false));
        outer.addView(settings, lp(-1, -2));

        TextView note = text("Una sola pressione del pulsante fisico avvia il provino. Dopo la prima esposizione, le successive partono automaticamente dopo la pausa.", 13, MUTED, false);
        note.setGravity(Gravity.CENTER);
        note.setPadding(dp(8), dp(10), dp(8), 0);
        outer.addView(note, lp(-1, -2));
        return outer;
    }

    private LinearLayout buildLogPanel() {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);

        LinearLayout intro = card();
        TextView title = text("LOG DI STAMPA", 17, TEXT_PRIMARY, true);
        title.setGravity(Gravity.CENTER);
        intro.addView(title);
        TextView sub = text("Schede di camera oscura con tempi compilati automaticamente", 13, MUTED, false);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, dp(4), 0, dp(10));
        intro.addView(sub);

        Button add = compactButton("+  NUOVA SCHEDA");
        add.setOnClickListener(v -> showLogEditor(newEntryFromSession(), true));
        intro.addView(add, lp(-1, dp(50)));

        LinearLayout backupRow = new LinearLayout(this);
        backupRow.setOrientation(LinearLayout.HORIZONTAL);
        Button exportBackup = compactButton("ESPORTA BACKUP");
        Button importBackup = compactButton("IMPORTA BACKUP");
        exportBackup.setOnClickListener(v -> exportLogBackup());
        importBackup.setOnClickListener(v -> importLogBackup());
        backupRow.addView(exportBackup, margin(lp(0, dp(46), 1f), 0, dp(8), dp(4), 0));
        backupRow.addView(importBackup, margin(lp(0, dp(46), 1f), dp(4), dp(8), 0, 0));
        intro.addView(backupRow, lp(-1, -2));
        outer.addView(intro, margin(lp(-1, -2), 0, 0, 0, 10));

        logListContainer = new LinearLayout(this);
        logListContainer.setOrientation(LinearLayout.VERTICAL);
        outer.addView(logListContainer, lp(-1, -2));
        refreshLogList();
        return outer;
    }

    private void refreshLogList() {
        if (logListContainer == null) return;
        logListContainer.removeAllViews();
        List<LogEntry> entries = LogStore.load(this);
        if (entries.isEmpty()) {
            LinearLayout empty = card();
            TextView t = text("Nessuna scheda salvata", 15, MUTED, true);
            t.setGravity(Gravity.CENTER);
            empty.addView(t);
            TextView s = text("Dopo una stampa o un provino comparirà SALVA NEL LOG.", 13, MUTED, false);
            s.setGravity(Gravity.CENTER);
            s.setPadding(0, dp(6), 0, 0);
            empty.addView(s);
            logListContainer.addView(empty, lp(-1, -2));
            return;
        }

        for (LogEntry e : entries) {
            Button row = new Button(this);
            String name = e.title == null || e.title.trim().isEmpty() ? "Scheda senza titolo" : e.title.trim();
            StringBuilder b = new StringBuilder(name);
            b.append("\n").append(formatDate(e.timestamp)).append(" • ").append(formatClock(e.timestamp));
            if (e.exposureMs > 0) b.append("   •   Stampa ").append(formatTime(e.exposureMs));
            if (e.testMs > 0) {
                b.append("\nProvino ").append(formatTime(e.testMs));
                if (e.testCount > 0) b.append(" × ").append(e.testCount);
            }
            row.setText(b.toString());
            row.setTextSize(14);
            row.setAllCaps(false);
            row.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
            row.setPadding(dp(16), dp(8), dp(12), dp(8));
            row.setTextColor(TEXT_PRIMARY);
            row.setBackground(roundRect(CARD, 10, 1, BORDER));
            row.setOnClickListener(v -> showLogEditor(e, false));
            logListContainer.addView(row, margin(lp(-1, dp(e.testMs > 0 ? 82 : 66)), 0, 0, 0, 8));
        }
    }

    private LogEntry newEntryFromSession() {
        SharedPreferences p = getSharedPreferences("log_session", MODE_PRIVATE);
        long now = System.currentTimeMillis();
        long cycle = p.getLong("lastCycleAt", 0L);
        long printAt = p.getLong("lastPrintAt", 0L);
        long testAt = p.getLong("lastTestAt", 0L);
        long anchor = cycle > 0 ? cycle : Math.max(printAt, testAt);
        if (anchor <= 0) anchor = now;

        LogEntry e = new LogEntry();
        e.id = now;
        e.timestamp = anchor;
        // A print log always carries the latest completed print and the latest completed test strip.
        // No time window: the user's rule is simply "associate the last test strip to the print".
        if (printAt > 0 && printAt >= testAt) {
            e.timestamp = printAt;
            e.exposureMs = p.getInt("lastPrintMs", 0);
            if (testAt > 0) {
                e.testMs = p.getInt("lastTestMs", 0);
                e.testCount = p.getInt("lastTestCount", 0);
            }
        } else if (testAt > 0) {
            // If the most recent completed cycle is only a test strip, keep the existing
            // quick-save behaviour: test data only, until a final print is made.
            e.timestamp = testAt;
            e.testMs = p.getInt("lastTestMs", 0);
            e.testCount = p.getInt("lastTestCount", 0);
        }

        // Defaults for every new print card; all remain editable in the editor.
        e.aperture = "11,5";
        e.magenta = "0";
        e.yellow = "0";
        e.density = "0";
        e.paper = "Fomaspeed Variant 311 RC lucida";
        return e;
    }

    private boolean shouldOfferQuickSave() {
        SharedPreferences session = getSharedPreferences("log_session", MODE_PRIVATE);
        long cycle = session.getLong("lastCycleAt", 0L);
        long saved = getSharedPreferences("ui", MODE_PRIVATE).getLong("lastSavedCycleAt", 0L);
        return cycle > saved;
    }

    private void markCurrentSessionSaved(LogEntry e) {
        long cycle = getSharedPreferences("log_session", MODE_PRIVATE).getLong("lastCycleAt", 0L);
        if (cycle > 0 && e.timestamp == cycle) {
            getSharedPreferences("ui", MODE_PRIVATE).edit().putLong("lastSavedCycleAt", cycle).apply();
        }
    }

    private void showLogEditor(final LogEntry entry, final boolean isNew) {
        if (darkroomMode) {
            new AlertDialog.Builder(this)
                    .setTitle("Compilazione scheda")
                    .setMessage("Per scrivere nei campi manuali è meglio uscire dalla modalità camera oscura: la tastiera di Android non è inattinica. Puoi comunque consultare il LOG in rosso.")
                    .setPositiveButton("VAI ALLE IMPOSTAZIONI", (d, w) -> showSettingsDialog())
                    .setNegativeButton("ANNULLA", null)
                    .show();
            return;
        }

        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        ScrollView sc = new ScrollView(this);
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(18), dp(16), dp(18), dp(18));
        panel.setBackground(roundRect(CARD, 14, 1, BORDER));
        sc.addView(panel, new ScrollView.LayoutParams(-1, -2));

        TextView heading = text(isNew ? "NUOVA SCHEDA DI STAMPA" : "SCHEDA DI STAMPA", 19, TEXT_PRIMARY, true);
        panel.addView(heading, margin(lp(-1, -2), 0, 0, 0, 12));

        LinearLayout auto = card();
        auto.addView(text("DATI AUTOMATICI", 13, MUTED, true));
        String exposure = entry.exposureMs > 0 ? formatTime(entry.exposureMs) : "—";
        String test = entry.testMs > 0 ? formatTime(entry.testMs) : "—";
        String ntest = entry.testCount > 0 ? String.valueOf(entry.testCount) : "—";
        TextView autoValues = text(
                "Esposizione finale: " + exposure +
                "\nProvino — sec striscia: " + test +
                "\nNumero esposizioni provino: " + ntest +
                "\nData: " + formatDate(entry.timestamp) +
                "\nOra: " + formatClock(entry.timestamp), 14, TEXT_PRIMARY, false);
        autoValues.setPadding(0, dp(6), 0, 0);
        auto.addView(autoValues);
        panel.addView(auto, margin(lp(-1, -2), 0, 0, 0, 12));

        final EditText title = editField("Titolo / nome stampa", entry.title);
        panel.addView(title, margin(lp(-1, dp(52)), 0, 0, 0, 8));

        TextView negLabel = text("NEGATIVO", 12, MUTED, true);
        panel.addView(negLabel, margin(lp(-1, -2), 0, 4, 0, 4));
        LinearLayout negRow = new LinearLayout(this);
        negRow.setOrientation(LinearLayout.HORIZONTAL);
        final String[] negative = {entry.negative == null ? "" : entry.negative};
        final Button b35 = compactButton("35mm");
        final Button b66 = compactButton("6×6");
        View.OnClickListener negRefresh = v -> {
            negative[0] = v == b35 ? "35mm" : "6x6";
            b35.setBackground(roundRect("35mm".equals(negative[0]) ? GREEN : BUTTON, 8, 1, BORDER));
            b66.setBackground(roundRect("6x6".equals(negative[0]) ? GREEN : BUTTON, 8, 1, BORDER));
            b35.setTextColor("35mm".equals(negative[0]) ? Color.BLACK : TEXT_PRIMARY);
            b66.setTextColor("6x6".equals(negative[0]) ? Color.BLACK : TEXT_PRIMARY);
        };
        b35.setOnClickListener(negRefresh);
        b66.setOnClickListener(negRefresh);
        negRow.addView(b35, margin(lp(0, dp(46), 1f), 0, 0, dp(4), 0));
        negRow.addView(b66, margin(lp(0, dp(46), 1f), dp(4), 0, 0, 0));
        panel.addView(negRow, margin(lp(-1, -2), 0, 0, 0, 8));
        if ("35mm".equals(negative[0])) b35.performClick();
        else if ("6x6".equals(negative[0])) b66.performClick();

        final EditText aperture = editField("Diaframma f/", entry.aperture);
        final EditText column = editField("Altezza colonna cm", entry.columnHeight);
        final EditText magenta = editField("Magenta", entry.magenta);
        final EditText yellow = editField("Yellow", entry.yellow);
        final EditText density = editField("Densità", entry.density);
        final EditText paper = editField("Carta", entry.paper == null || entry.paper.trim().isEmpty() ? "Fomaspeed Variant 311 RC lucida" : entry.paper);
        final EditText notes = editField("Note — max " + JpegCardRenderer.MAX_NOTES_CHARS + " caratteri", entry.notes);
        notes.setSingleLine(false);
        notes.setMinLines(2);
        notes.setMaxLines(3);
        notes.setFilters(new InputFilter[]{new InputFilter.LengthFilter(JpegCardRenderer.MAX_NOTES_CHARS)});
        if (notes.getText().length() > JpegCardRenderer.MAX_NOTES_CHARS) {
            notes.setText(notes.getText().subSequence(0, JpegCardRenderer.MAX_NOTES_CHARS));
            notes.setSelection(notes.getText().length());
        }
        panel.addView(aperture, margin(lp(-1, dp(52)), 0, 0, 0, 8));
        panel.addView(column, margin(lp(-1, dp(52)), 0, 0, 0, 8));
        panel.addView(magenta, margin(lp(-1, dp(52)), 0, 0, 0, 8));
        panel.addView(yellow, margin(lp(-1, dp(52)), 0, 0, 0, 8));
        panel.addView(density, margin(lp(-1, dp(52)), 0, 0, 0, 8));
        panel.addView(paper, margin(lp(-1, dp(52)), 0, 0, 0, 8));
        panel.addView(notes, margin(lp(-1, dp(84)), 0, 0, 0, 12));

        Button save = compactButton("SALVA SCHEDA");
        save.setBackground(roundRect(GREEN, 9, 0, 0));
        save.setTextColor(Color.BLACK);
        save.setOnClickListener(v -> {
            entry.title = title.getText().toString().trim();
            entry.negative = negative[0];
            entry.aperture = aperture.getText().toString().trim();
            entry.columnHeight = column.getText().toString().trim();
            entry.magenta = magenta.getText().toString().trim();
            entry.yellow = yellow.getText().toString().trim();
            entry.density = density.getText().toString().trim();
            entry.paper = paper.getText().toString().trim();
            entry.notes = trimNotes(notes.getText().toString().trim());
            if (entry.id <= 0) entry.id = System.currentTimeMillis();
            if (entry.timestamp <= 0) entry.timestamp = System.currentTimeMillis();
            LogStore.save(this, entry);
            markCurrentSessionSaved(entry);
            dialog.dismiss();
            Toast.makeText(this, "Scheda salvata nel LOG", Toast.LENGTH_SHORT).show();
            setMode(MODE_LOG);
            refreshLogList();
        });
        panel.addView(save, lp(-1, dp(52)));

        if (!isNew) {
            Button exportJpg = compactButton("ESPORTA SCHEDA JPG 9:16");
            exportJpg.setOnClickListener(v -> {
                entry.title = title.getText().toString().trim();
                entry.negative = negative[0];
                entry.aperture = aperture.getText().toString().trim();
                entry.columnHeight = column.getText().toString().trim();
                entry.magenta = magenta.getText().toString().trim();
                entry.yellow = yellow.getText().toString().trim();
                entry.density = density.getText().toString().trim();
                entry.paper = paper.getText().toString().trim();
                entry.notes = trimNotes(notes.getText().toString().trim());
                exportJpeg(entry);
            });
            panel.addView(exportJpg, margin(lp(-1, dp(50)), 0, 8, 0, 0));

            Button delete = compactButton("ELIMINA SCHEDA");
            delete.setTextColor(RED);
            delete.setOnClickListener(v -> new AlertDialog.Builder(this)
                    .setTitle("Eliminare questa scheda?")
                    .setMessage("L’operazione non può essere annullata.")
                    .setPositiveButton("ELIMINA", (d, w) -> {
                        LogStore.delete(this, entry.id);
                        dialog.dismiss();
                        refreshLogList();
                    })
                    .setNegativeButton("ANNULLA", null)
                    .show());
            panel.addView(delete, margin(lp(-1, dp(48)), 0, 8, 0, 0));
        }

        Button cancel = compactButton("ANNULLA");
        cancel.setOnClickListener(v -> dialog.dismiss());
        panel.addView(cancel, margin(lp(-1, dp(48)), 0, 8, 0, 0));

        dialog.setContentView(sc);
        Window w = dialog.getWindow();
        if (w != null) w.setBackgroundDrawableResource(android.R.color.transparent);
        dialog.show();
        if (w != null) w.setLayout((int)(getResources().getDisplayMetrics().widthPixels * 0.94f), (int)(getResources().getDisplayMetrics().heightPixels * 0.88f));
    }

    private EditText editField(String hint, String value) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(value == null ? "" : value);
        e.setTextSize(15);
        e.setTextColor(TEXT_PRIMARY);
        e.setHintTextColor(MUTED);
        e.setSingleLine(true);
        e.setPadding(dp(12), 0, dp(12), 0);
        e.setBackground(roundRect(BUTTON, 8, 1, BORDER));
        return e;
    }

    private static String trimNotes(String s) {
        String v = s == null ? "" : s;
        return v.length() <= JpegCardRenderer.MAX_NOTES_CHARS ? v : v.substring(0, JpegCardRenderer.MAX_NOTES_CHARS);
    }

    private static String formatDate(long timestamp) {
        return new SimpleDateFormat("dd/MM/yyyy", Locale.ITALY).format(new Date(timestamp));
    }

    private static String formatClock(long timestamp) {
        return new SimpleDateFormat("HH:mm", Locale.ITALY).format(new Date(timestamp));
    }


    private void exportLogBackup() {
        Intent i = new Intent("android.intent.action.CREATE_DOCUMENT");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/json");
        String name = "DarkroomTimer-LOG-backup-" + new SimpleDateFormat("yyyyMMdd-HHmm", Locale.ITALY).format(new Date()) + ".json";
        i.putExtra(Intent.EXTRA_TITLE, name);
        startActivityForResult(i, REQ_EXPORT_BACKUP);
    }

    private void importLogBackup() {
        Intent i = new Intent("android.intent.action.OPEN_DOCUMENT");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/json");
        startActivityForResult(i, REQ_IMPORT_BACKUP);
    }

    private void exportJpeg(LogEntry entry) {
        pendingJpegEntry = entry;
        Intent i = new Intent("android.intent.action.CREATE_DOCUMENT");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/jpeg");
        String base = entry == null || entry.title == null || entry.title.trim().isEmpty()
                ? "Scheda-tecnica-stampa"
                : "Scheda-" + safeFileName(entry.title.trim());
        i.putExtra(Intent.EXTRA_TITLE, base + ".jpg");
        startActivityForResult(i, REQ_EXPORT_JPG);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            if (requestCode == REQ_EXPORT_BACKUP) {
                String json = BackupManager.exportJson(this);
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new Exception("Impossibile aprire il file scelto");
                    out.write(json.getBytes(StandardCharsets.UTF_8));
                }
                Toast.makeText(this, "Backup LOG esportato", Toast.LENGTH_SHORT).show();
            } else if (requestCode == REQ_IMPORT_BACKUP) {
                String json = readTextUri(uri);
                final List<LogEntry> imported = BackupManager.parseJson(json);
                new AlertDialog.Builder(this)
                        .setTitle("Importa backup LOG")
                        .setMessage("Trovate " + imported.size() + " schede. Vuoi unirle al LOG attuale oppure sostituire completamente il LOG?")
                        .setPositiveButton("UNISCI", (d, w) -> {
                            LogStore.merge(this, imported);
                            refreshLogList();
                            Toast.makeText(this, "Backup unito al LOG", Toast.LENGTH_SHORT).show();
                        })
                        .setNeutralButton("SOSTITUISCI", (d, w) -> {
                            LogStore.replaceAll(this, imported);
                            refreshLogList();
                            Toast.makeText(this, "LOG ripristinato dal backup", Toast.LENGTH_SHORT).show();
                        })
                        .setNegativeButton("ANNULLA", null)
                        .show();
            } else if (requestCode == REQ_EXPORT_JPG) {
                if (pendingJpegEntry == null) throw new Exception("Nessuna scheda da esportare");
                Bitmap bitmap = JpegCardRenderer.render(pendingJpegEntry, APP_VERSION);
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new Exception("Impossibile aprire il file scelto");
                    if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 94, out)) throw new Exception("Creazione JPG non riuscita");
                } finally {
                    bitmap.recycle();
                    pendingJpegEntry = null;
                }
                Toast.makeText(this, "Scheda JPG esportata", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Operazione non riuscita: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private String readTextUri(Uri uri) throws Exception {
        StringBuilder b = new StringBuilder();
        try (InputStream in = getContentResolver().openInputStream(uri);
             BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) b.append(line).append('\n');
        }
        return b.toString();
    }

    private static String safeFileName(String s) {
        String v = s == null ? "scheda" : s.replaceAll("[^A-Za-z0-9À-ÿ._-]+", "-");
        v = v.replaceAll("-+", "-");
        if (v.length() > 48) v = v.substring(0, 48);
        return v.isEmpty() ? "scheda" : v;
    }

    private void showTechnicalLogDialog() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(18), dp(16), dp(18), dp(18));
        panel.setBackground(roundRect(darkroomMode ? Color.BLACK : CARD, 14, 1, BORDER));

        TextView heading = text("CRONOLOGIA TECNICA", 18, TEXT_PRIMARY, true);
        panel.addView(heading, margin(lp(-1, -2), 0, 0, 0, 6));
        TextView expl = text("Ultimi 20 cicli: eventi osservati dal MINIR2 sulla LAN. I tempi includono la latenza di rete/polling e servono alla diagnostica, non come misura metrologica.", 12, MUTED, false);
        panel.addView(expl, margin(lp(-1, -2), 0, 0, 0, 10));

        ScrollView sc = new ScrollView(this);
        TextView body = text(TechnicalLog.formatForDisplay(this), 11, TEXT_PRIMARY, false);
        body.setTypeface(Typeface.MONOSPACE);
        body.setTextIsSelectable(true);
        body.setPadding(dp(10), dp(10), dp(10), dp(10));
        body.setBackground(roundRect(BUTTON, 8, 1, BORDER));
        sc.addView(body, new ScrollView.LayoutParams(-1, -2));
        panel.addView(sc, lp(-1, dp(420)));

        Button clear = compactButton("AZZERA CRONOLOGIA TECNICA");
        clear.setTextColor(RED);
        clear.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Azzerare la cronologia tecnica?")
                .setPositiveButton("AZZERA", (d, w) -> {
                    TechnicalLog.clear(this);
                    body.setText("Nessun ciclo tecnico registrato.");
                })
                .setNegativeButton("ANNULLA", null)
                .show());
        panel.addView(clear, margin(lp(-1, dp(48)), 0, 10, 0, 0));

        Button close = compactButton("CHIUDI");
        close.setOnClickListener(v -> dialog.dismiss());
        panel.addView(close, margin(lp(-1, dp(48)), 0, 8, 0, 0));

        dialog.setContentView(panel);
        Window w = dialog.getWindow();
        if (w != null) w.setBackgroundDrawableResource(android.R.color.transparent);
        dialog.show();
        if (w != null) w.setLayout((int)(getResources().getDisplayMetrics().widthPixels * 0.96f), (int)(getResources().getDisplayMetrics().heightPixels * 0.88f));
    }

    private LinearLayout stepperRow(String label, boolean isCount) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(5), 0, dp(5));

        TextView name = text(label, 13, MUTED, true);
        row.addView(name, lp(0, dp(54), 1f));
        Button minus = smallCompactButton("−");
        Button plus = smallCompactButton("+");
        TextView value = text(isCount ? String.valueOf(testCount) : formatTime(testPauseMs), 22, BLUE, true);
        value.setGravity(Gravity.CENTER);
        if (isCount) testCountText = value; else testPauseText = value;
        row.addView(minus, lp(dp(48), dp(46)));
        row.addView(value, lp(dp(86), dp(50)));
        row.addView(plus, lp(dp(48), dp(46)));

        if (isCount) {
            minus.setOnClickListener(v -> setTestCount(testCount - 1));
            plus.setOnClickListener(v -> setTestCount(testCount + 1));
        } else {
            minus.setOnClickListener(v -> setTestPause(testPauseMs - 500));
            plus.setOnClickListener(v -> setTestPause(testPauseMs + 500));
        }
        return row;
    }

    private void setMode(int newMode) {
        if (armed) return;
        mode = newMode;
        getSharedPreferences("ui", MODE_PRIVATE).edit().putInt("mode", mode).apply();
        if (mode == MODE_LOG) refreshLogList();
        applyModeUi();
    }

    private void applyModeUi() {
        boolean print = mode == MODE_PRINT;
        boolean test = mode == MODE_TEST;
        boolean log = mode == MODE_LOG;
        printPanel.setVisibility(print ? View.VISIBLE : View.GONE);
        testPanel.setVisibility(test ? View.VISIBLE : View.GONE);
        logPanel.setVisibility(log ? View.VISIBLE : View.GONE);
        actionButton.setVisibility(log ? View.GONE : View.VISIBLE);
        stateText.setVisibility(log ? View.GONE : View.VISIBLE);
        saveLogButton.setVisibility(!log && shouldOfferQuickSave() ? View.VISIBLE : View.GONE);

        if (darkroomMode) {
            printModeButton.setTextColor(print ? Color.BLACK : TEXT_PRIMARY);
            testModeButton.setTextColor(test ? Color.BLACK : TEXT_PRIMARY);
            logModeButton.setTextColor(log ? Color.BLACK : TEXT_PRIMARY);
            printModeButton.setBackground(roundRect(print ? GREEN : BUTTON, 9, 1, BORDER));
            testModeButton.setBackground(roundRect(test ? BLUE : BUTTON, 9, 1, BORDER));
            logModeButton.setBackground(roundRect(log ? RED : BUTTON, 9, 1, BORDER));
            actionButton.setTextColor(Color.BLACK);
        } else {
            printModeButton.setTextColor(print ? TEXT_PRIMARY : MUTED);
            testModeButton.setTextColor(test ? TEXT_PRIMARY : MUTED);
            logModeButton.setTextColor(log ? TEXT_PRIMARY : MUTED);
            printModeButton.setBackground(roundRect(print ? GREEN : BUTTON, 9, print ? 0 : 1, BORDER));
            testModeButton.setBackground(roundRect(test ? BLUE : BUTTON, 9, test ? 0 : 1, BORDER));
            logModeButton.setBackground(roundRect(log ? PURPLE : BUTTON, 9, log ? 0 : 1, BORDER));
            actionButton.setTextColor(TEXT_PRIMARY);
        }
        if (!log) {
            actionButton.setBackground(roundRect(print ? GREEN : BLUE, 10, 0, 0));
            actionButton.setText(print ? "ARMA STAMPA • " + formatTime(printWidthMs)
                    : "ARMA PROVINO • " + testCount + " × " + formatTime(testWidthMs));
        }
    }

    private void arm() {
        if (mode == MODE_LOG) return;
        if (device == null || !device.isValid()) {
            stateText.setText("Il SONOFF dell’ingranditore non è ancora verificato in DIY");
            return;
        }
        armed = true;
        stateText.setTextColor(MUTED);
        stateText.setText(mode == MODE_PRINT ? "Imposto Inching…" : "Preparo il provino…");
        setControlsEnabled(false);

        Intent i;
        if (mode == MODE_PRINT) {
            i = new Intent(this, SonoffArmService.class).setAction(SonoffArmService.ACTION_ARM_PRINT);
            i.putExtra(SonoffArmService.EXTRA_WIDTH, printWidthMs);
        } else {
            i = new Intent(this, SonoffArmService.class).setAction(SonoffArmService.ACTION_ARM_TEST);
            i.putExtra(SonoffArmService.EXTRA_WIDTH, testWidthMs);
            i.putExtra(SonoffArmService.EXTRA_COUNT, testCount);
            i.putExtra(SonoffArmService.EXTRA_PAUSE, testPauseMs);
        }
        startServiceCompat(i);
    }

    private void disarm() {
        if (device == null || !device.isValid()) {
            stateText.setText("Nessun SONOFF DIY verificato");
            return;
        }
        stateText.setTextColor(MUTED);
        stateText.setText("Ripristino ON/OFF normale…");
        Intent i = new Intent(this, SonoffArmService.class).setAction(SonoffArmService.ACTION_DISARM);
        startServiceCompat(i);
    }

    private void startServiceCompat(Intent intent) {
        if (Build.VERSION.SDK_INT >= 26) {
            try {
                java.lang.reflect.Method m = Context.class.getMethod("startForegroundService", Intent.class);
                m.invoke(this, intent);
                return;
            } catch (Exception ignored) {}
        }
        startService(intent);
    }

    private void setPrintTime(int ms) {
        if (armed) return;
        printWidthMs = snap(ms, 500, 36_000_000);
        getSharedPreferences("ui", MODE_PRIVATE).edit().putInt("printWidthMs", printWidthMs).apply();
        printTimeText.setText(formatTime(printWidthMs));
        applyModeUi();
    }

    private void setTestTime(int ms) {
        if (armed) return;
        testWidthMs = snap(ms, 500, 30_000);
        getSharedPreferences("ui", MODE_PRIVATE).edit().putInt("testWidthMs", testWidthMs).apply();
        testTimeText.setText(formatTime(testWidthMs));
        updateCumulativeTimes();
        applyModeUi();
    }

    private void setTestCount(int n) {
        if (armed) return;
        testCount = Math.max(2, Math.min(20, n));
        getSharedPreferences("ui", MODE_PRIVATE).edit().putInt("testCount", testCount).apply();
        testCountText.setText(String.valueOf(testCount));
        updateCumulativeTimes();
        applyModeUi();
    }

    private void setTestPause(int ms) {
        if (armed) return;
        testPauseMs = snap(ms, 500, 60_000);
        getSharedPreferences("ui", MODE_PRIVATE).edit().putInt("testPauseMs", testPauseMs).apply();
        testPauseText.setText(formatTime(testPauseMs));
    }

    private void updateSelectionUiBeforeDiscovery() {
        if (selectedDeviceId == null || selectedDeviceId.isEmpty()) {
            deviceStatus.setText("●  SONOFF NON CONFIGURATO");
            deviceStatus.setTextColor(MUTED);
            selectDeviceButton.setText("⚙");
            stateText.setText("Apri le impostazioni e scegli il SONOFF dell’ingranditore.");
        } else {
            deviceStatus.setText("●  SONOFF — connessione…");
            deviceStatus.setTextColor(MUTED);
            selectDeviceButton.setText("⚙");
            stateText.setText("CONNESSIONE — cerco il SONOFF dell’ingranditore…");
        }
    }

    private void showDevicePicker() {
        if (foundDevices.isEmpty()) {
            new AlertDialog.Builder(this)
                    .setTitle("Nessun SONOFF trovato")
                    .setMessage("Attendi qualche secondo con il telefono collegato alla stessa rete Wi‑Fi dei SONOFF, poi riprova.")
                    .setPositiveButton("OK", null)
                    .show();
            return;
        }

        List<FoundDevice> list = new ArrayList<>(foundDevices.values());
        Collections.sort(list, Comparator.comparing(a -> a.config.deviceId));
        String[] labels = new String[list.size()];
        for (int i = 0; i < list.size(); i++) {
            FoundDevice f = list.get(i);
            String selected = f.config.deviceId.equals(selectedDeviceId) ? "  ✓" : "";
            labels[i] = "ID " + f.config.deviceId + selected + "\n" +
                    f.config.host + ":" + f.config.port + " • " + f.modeLabel();
        }

        new AlertDialog.Builder(this)
                .setTitle("Scegli il SONOFF dell’ingranditore")
                .setItems(labels, (dialog, which) -> selectDevice(list.get(which)))
                .setNegativeButton("ANNULLA", null)
                .show();
    }

    private void selectDevice(FoundDevice found) {
        selectedDeviceId = found.config.deviceId;
        found.config.save(this);
        device = null;
        setControlsEnabled(false);
        selectDeviceButton.setText("⚙");
        applySelectedFound(found);
    }

    private void applySelectedFound(FoundDevice found) {
        if (!found.config.deviceId.equals(selectedDeviceId)) return;
        if (found.diyCandidate) {
            deviceStatus.setText("●  SONOFF — verifica DIY…");
            deviceStatus.setTextColor(MUTED);
            stateText.setTextColor(MUTED);
            stateText.setText("CONNESSIONE — verifico il SONOFF…");
            validateSelected(found.config);
        } else {
            device = null;
            setControlsEnabled(false);
            deviceStatus.setText("●  SONOFF NON IN DIY");
            deviceStatus.setTextColor(AMBER);
            stateText.setTextColor(AMBER);
            stateText.setText("SONOFF NON IN DIY — controlla le impostazioni.");
        }
    }

    private void validateSelected(DeviceConfig d) {
        if (d == null || !d.isValid()) return;
        if (!d.deviceId.equals(selectedDeviceId)) return;
        if (!validationInFlight.compareAndSet(false, true)) return;

        io.execute(() -> {
            Exception last = null;
            try {
                // The DIY endpoint can occasionally miss a request while Wi-Fi/NSD is
                // settling. A single timeout must not make the UI look permanently dead.
                for (int attempt = 1; attempt <= 4; attempt++) {
                    if (!activityStarted || !d.deviceId.equals(selectedDeviceId)) return;
                    try {
                        SonoffHttp.info(d);
                        if (!d.deviceId.equals(selectedDeviceId)) return;
                        d.save(this);
                        runOnUiThread(() -> {
                            if (!d.deviceId.equals(selectedDeviceId)) return;
                            device = d;
                            connectionFailures = 0;
                            deviceStatus.setText("●  SONOFF CONNESSO");
                            deviceStatus.setTextColor(GREEN);
                            restoreRuntimeState();
                        });
                        return;
                    } catch (Exception e) {
                        last = e;
                        if (attempt < 4) {
                            try { Thread.sleep(550L); } catch (InterruptedException ie) {
                                Thread.currentThread().interrupt();
                                return;
                            }
                        }
                    }
                }

                if (!d.deviceId.equals(selectedDeviceId)) return;
                runOnUiThread(() -> {
                    if (!d.deviceId.equals(selectedDeviceId)) return;
                    // Keep retrying automatically: the selected Device ID is still the
                    // source of truth and discovery may shortly provide a new DHCP IP.
                    device = null;
                    setControlsEnabled(false);
                    deviceStatus.setText("●  SONOFF — RICONNESSIONE…");
                    deviceStatus.setTextColor(AMBER);
                    stateText.setTextColor(AMBER);
                    stateText.setText("RICONNESSIONE AUTOMATICA — nessuna azione richiesta");
                    // The periodic heartbeat/discovery loop will keep retrying.
                });
            } finally {
                validationInFlight.set(false);
            }
        });
    }

    private void healthCheckSelected(DeviceConfig d) {
        if (d == null || !d.isValid() || armed) return;
        if (!d.deviceId.equals(selectedDeviceId)) return;
        if (!healthCheckInFlight.compareAndSet(false, true)) return;

        io.execute(() -> {
            try {
                SonoffHttp.infoQuick(d, 1100);
                if (!d.deviceId.equals(selectedDeviceId)) return;
                d.save(this);
                runOnUiThread(() -> {
                    if (!d.deviceId.equals(selectedDeviceId) || armed) return;
                    connectionFailures = 0;
                    device = d;
                    deviceStatus.setText("●  SONOFF CONNESSO");
                    deviceStatus.setTextColor(GREEN);
                    restoreRuntimeState();
                });
            } catch (Exception e) {
                if (!d.deviceId.equals(selectedDeviceId)) return;
                runOnUiThread(() -> {
                    if (!d.deviceId.equals(selectedDeviceId) || armed) return;
                    connectionFailures++;
                    setControlsEnabled(false);
                    if (connectionFailures < 2) {
                        deviceStatus.setText("●  VERIFICA CONNESSIONE…");
                        deviceStatus.setTextColor(AMBER);
                        stateText.setTextColor(AMBER);
                        stateText.setText("VERIFICA CONNESSIONE — attendo il MINIR2…");
                    } else {
                        device = null;
                        deviceStatus.setText("●  SONOFF NON RAGGIUNGIBILE");
                        deviceStatus.setTextColor(RED);
                        stateText.setTextColor(RED);
                        stateText.setText("SONOFF NON RAGGIUNGIBILE — verifica la rete.");
                    }
                });
            } finally {
                healthCheckInFlight.set(false);
            }
        });
    }

    @Override public void onSearching() {
        if (selectedDeviceId == null || selectedDeviceId.isEmpty()) {
            deviceStatus.setText("●  SONOFF — ricerca…");
            deviceStatus.setTextColor(MUTED);
        } else if (device == null || !device.isValid()) {
            deviceStatus.setText("●  SONOFF — connessione…");
            deviceStatus.setTextColor(MUTED);
        }
    }

    @Override public void onDiyCandidate(DeviceConfig found, String type, String apiVersion) {
        FoundDevice f = new FoundDevice(found, true, type, apiVersion);
        foundDevices.put(found.deviceId, f);
        if (found.deviceId.equals(selectedDeviceId)) {
            applySelectedFound(f);
        } else if (selectedDeviceId == null || selectedDeviceId.isEmpty()) {
            showCountWithoutSelection();
        }
    }

    @Override public void onEwelinkMode(String host, int port, String deviceId, String type) {
        DeviceConfig cfg = new DeviceConfig(host, port, deviceId);
        FoundDevice f = new FoundDevice(cfg, false, type, "");
        foundDevices.put(deviceId, f);
        if (deviceId.equals(selectedDeviceId)) {
            cfg.save(this);
            applySelectedFound(f);
        } else if (selectedDeviceId == null || selectedDeviceId.isEmpty()) {
            showCountWithoutSelection();
        }
    }

    private void showCountWithoutSelection() {
        int n = foundDevices.size();
        deviceStatus.setText("●  SONOFF DA SELEZIONARE");
        deviceStatus.setTextColor(MUTED);
        selectDeviceButton.setText("⚙");
        stateText.setTextColor(MUTED);
        stateText.setText("Apri le impostazioni per scegliere l’ingranditore.");
    }

    @Override public void onError(String message) {
        if (device == null || !device.isValid()) {
            if (foundDevices.isEmpty()) {
                deviceStatus.setText("●  SONOFF NON RAGGIUNGIBILE");
                deviceStatus.setTextColor(RED);
            }
        }
    }

    private void setControlsEnabled(boolean enabled) {
        boolean ready = enabled && device != null && device.isValid() && !armed;
        actionButton.setEnabled(ready);
        actionButton.setAlpha(ready ? 1f : (darkroomMode ? 0.62f : 0.45f));
        printModeButton.setEnabled(!armed);
        testModeButton.setEnabled(!armed);
        logModeButton.setEnabled(!armed);
        selectDeviceButton.setEnabled(!armed);
        selectDeviceButton.setAlpha(selectDeviceButton.isEnabled() ? 1f : (darkroomMode ? 0.62f : 0.45f));
        normalButton.setEnabled(device != null && device.isValid());
        normalButton.setAlpha(normalButton.isEnabled() ? 1f : (darkroomMode ? 0.62f : 0.45f));

        // During ARMATO / ESPOSIZIONE / PAUSA / DISARMO the parameters are not only
        // ignored by setters: their controls are visibly locked to prevent accidental taps.
        setTreeEnabled(printPanel, !armed);
        setTreeEnabled(testPanel, !armed);
        if (printPanel != null) printPanel.setAlpha(armed ? 0.58f : 1f);
        if (testPanel != null) testPanel.setAlpha(armed ? 0.58f : 1f);
    }

    private void setTreeEnabled(View view, boolean enabled) {
        if (view == null) return;
        view.setEnabled(enabled);
        if (view instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) view;
            for (int i = 0; i < g.getChildCount(); i++) setTreeEnabled(g.getChildAt(i), enabled);
        }
    }


    private void configurePalette() {
        if (darkroomMode) {
            // Safelight mode: use only the red subpixel (G=B=0) for emitted light.
            // Strong contrast comes from pure-red-on-black and black-on-red, not white.
            GREEN = Color.rgb(235, 0, 0);
            BLUE = Color.rgb(235, 0, 0);
            CARD = Color.BLACK;
            BUTTON = Color.rgb(18, 0, 0);
            BORDER = Color.rgb(105, 0, 0);
            MUTED = Color.rgb(190, 0, 0);
            AMBER = Color.rgb(235, 0, 0);
            RED = Color.rgb(255, 0, 0);
            PURPLE = RED;
            TEXT_PRIMARY = Color.rgb(255, 0, 0);
        } else {
            GREEN = Color.rgb(80, 207, 70);
            BLUE = Color.rgb(63, 151, 255);
            CARD = Color.rgb(18, 21, 23);
            BUTTON = Color.rgb(31, 35, 38);
            BORDER = Color.rgb(57, 63, 68);
            MUTED = Color.rgb(169, 176, 184);
            AMBER = Color.rgb(255, 181, 71);
            RED = Color.rgb(255, 92, 92);
            PURPLE = Color.rgb(136, 83, 178);
            TEXT_PRIMARY = Color.WHITE;
        }
        try { getWindow().getClass().getMethod("setStatusBarColor", int.class).invoke(getWindow(), Color.BLACK); } catch (Exception ignored) {}
        try { getWindow().getClass().getMethod("setNavigationBarColor", int.class).invoke(getWindow(), Color.BLACK); } catch (Exception ignored) {}
    }

    private void applyDarkroomWindow() {
        Window w = getWindow();
        if (w == null) return;
        if (darkroomMode) {
            try {
                w.getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_FULLSCREEN
                                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | 4096
                                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            } catch (Exception ignored) {}
            try {
                android.view.WindowManager.LayoutParams lp = w.getAttributes();
                lp.screenBrightness = 0.10f;
                w.setAttributes(lp);
            } catch (Exception ignored) {}
        } else {
            try { w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE); } catch (Exception ignored) {}
            try {
                android.view.WindowManager.LayoutParams lp = w.getAttributes();
                lp.screenBrightness = -1f;
                w.setAttributes(lp);
            } catch (Exception ignored) {}
        }
    }

    private String cumulativeTimes() {
        StringBuilder b = new StringBuilder("TEMPI CUMULATIVI  ");
        for (int i = 1; i <= testCount; i++) {
            if (i > 1) b.append("  •  ");
            b.append(formatTime(testWidthMs * i));
        }
        return b.toString();
    }

    private void updateCumulativeTimes() {
        if (testCumulativeText != null) testCumulativeText.setText(cumulativeTimes());
    }

    private void showSettingsDialog() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(20), dp(18), dp(20), dp(18));
        panel.setBackground(roundRect(darkroomMode ? Color.BLACK : CARD, 14, 1, BORDER));

        TextView title = text("IMPOSTAZIONI", 20, TEXT_PRIMARY, true);
        panel.addView(title, margin(lp(-1, -2), 0, 0, 0, 14));

        Button dark = compactButton("MODALITÀ CAMERA OSCURA: " + (darkroomMode ? "ON" : "OFF"));
        dark.setOnClickListener(v -> {
            getSharedPreferences("ui", MODE_PRIVATE).edit().putBoolean("darkroomMode", !darkroomMode).apply();
            dialog.dismiss();
            recreate();
        });
        panel.addView(dark, margin(lp(-1, dp(50)), 0, 0, 0, 8));

        Button beep = compactButton("BEEP FINE CICLO: " + (feedbackBeep ? "ON" : "OFF"));
        beep.setOnClickListener(v -> {
            feedbackBeep = !feedbackBeep;
            getSharedPreferences("ui", MODE_PRIVATE).edit().putBoolean("feedbackBeep", feedbackBeep).apply();
            beep.setText("BEEP FINE CICLO: " + (feedbackBeep ? "ON" : "OFF"));
        });
        panel.addView(beep, margin(lp(-1, dp(50)), 0, 0, 0, 8));

        Button diagnostics = compactButton("CRONOLOGIA TECNICA");
        diagnostics.setOnClickListener(v -> showTechnicalLogDialog());
        panel.addView(diagnostics, margin(lp(-1, dp(50)), 0, 0, 0, 14));

        DeviceConfig saved = DeviceConfig.load(this);
        String tech = "SONOFF INGRANDITORE\n";
        if (selectedDeviceId == null || selectedDeviceId.isEmpty()) {
            tech += "Nessun dispositivo selezionato";
        } else {
            tech += (device != null && device.isValid() ? "DIY verificata" : "non verificato")
                    + "\nDevice ID: " + selectedDeviceId
                    + (saved.host == null || saved.host.isEmpty() ? "" : "\nIP: " + saved.host + ":" + saved.port);
        }
        TextView details = text(tech, 13, MUTED, false);
        details.setPadding(dp(4), dp(2), dp(4), dp(10));
        panel.addView(details);

        Button change = compactButton(selectedDeviceId == null || selectedDeviceId.isEmpty() ? "SCEGLI SONOFF" : "CAMBIA SONOFF");
        change.setOnClickListener(v -> { dialog.dismiss(); showDevicePicker(); });
        panel.addView(change, margin(lp(-1, dp(50)), 0, 0, 0, 8));

        Button close = compactButton("CHIUDI");
        close.setOnClickListener(v -> dialog.dismiss());
        panel.addView(close, lp(-1, dp(50)));

        dialog.setContentView(panel);
        Window w = dialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawableResource(android.R.color.transparent);
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        dialog.show();
        if (w != null) w.setLayout((int)(getResources().getDisplayMetrics().widthPixels * 0.92f), ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private static int snap(int ms, int min, int max) {
        ms = Math.max(min, Math.min(max, ms));
        return Math.round(ms / 500f) * 500;
    }

    private static String formatTime(int ms) {
        return String.format(Locale.ITALY, "%.1f s", ms / 1000.0);
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(15), dp(15), dp(15), dp(15));
        l.setBackground(roundRect(CARD, 12, 1, BORDER));
        return l;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button modeButton(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(15);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setAllCaps(false);
        b.setPadding(0, 0, 0, 0);
        return b;
    }

    private Button compactButton(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextColor(TEXT_PRIMARY);
        b.setTextSize(12);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setAllCaps(false);
        b.setPadding(0, 0, 0, 0);
        b.setBackground(roundRect(BUTTON, 8, 1, BORDER));
        return b;
    }

    private Button smallButton(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(28);
        b.setTextColor(darkroomMode ? TEXT_PRIMARY : Color.rgb(195, 204, 210));
        b.setAllCaps(false);
        b.setPadding(0, 0, 0, 0);
        b.setBackground(roundRect(BUTTON, 10, 0, 0));
        return b;
    }

    private Button smallCompactButton(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(23);
        b.setTextColor(darkroomMode ? TEXT_PRIMARY : Color.rgb(195, 204, 210));
        b.setAllCaps(false);
        b.setPadding(0, 0, 0, 0);
        b.setBackground(roundRect(BUTTON, 8, 0, 0));
        return b;
    }

    private Button shortcutButton(String s, int accent) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(15);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(accent);
        b.setAllCaps(false);
        b.setBackground(roundRect(BUTTON, 8, 0, 0));
        b.setPadding(0, 0, 0, 0);
        return b;
    }

    private GradientDrawable roundRect(int color, int radiusDp, int strokeDp, int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) g.setStroke(dp(strokeDp), strokeColor);
        return g;
    }

    private View divider() {
        View v = new View(this);
        v.setBackgroundColor(darkroomMode ? BORDER : Color.rgb(42, 47, 50));
        v.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)));
        return v;
    }

    private View space(int d) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(d)));
        return v;
    }

    private int dp(int d) { return Math.round(d * getResources().getDisplayMetrics().density); }

    private static LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w, h); }
    private static LinearLayout.LayoutParams lp(int w, int h, float weight) { return new LinearLayout.LayoutParams(w, h, weight); }
    private static LinearLayout.LayoutParams margin(LinearLayout.LayoutParams p, int l, int t, int r, int b) {
        p.setMargins(l, t, r, b);
        return p;
    }
}
