# Darkroom Timer DIY — v0.5.7

Hotfix grafico minimale sulla base stabile v0.5.5.

- rimossa esclusivamente l’illustrazione vaschetta/pinza nella parte bassa della scheda JPG;
- mantenuta l’icona ingranditore in alto;
- nessuna modifica a timer, rete, diagnostica, LOG, backup, colori o modalità camera oscura;
- versionCode 21 / versionName 0.5.7.
